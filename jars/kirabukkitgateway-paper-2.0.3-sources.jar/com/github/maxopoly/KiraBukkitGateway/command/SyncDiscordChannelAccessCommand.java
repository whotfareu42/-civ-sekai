package com.github.maxopoly.KiraBukkitGateway.command;

import co.aikar.commands.BaseCommand;
import co.aikar.commands.annotation.CommandAlias;
import co.aikar.commands.annotation.Description;
import co.aikar.commands.annotation.Syntax;
import com.github.maxopoly.KiraBukkitGateway.KiraBukkitGatewayPlugin;
import java.util.Collection;
import java.util.HashSet;
import java.util.UUID;
import org.bukkit.ChatColor;
import org.bukkit.entity.Player;
import vg.civcraft.mc.namelayer.GroupManager;
import vg.civcraft.mc.namelayer.NameLayerAPI;
import vg.civcraft.mc.namelayer.group.Group;
import vg.civcraft.mc.namelayer.permission.PermissionType;

public class SyncDiscordChannelAccessCommand extends BaseCommand {

    @CommandAlias("syncdiscordchannel")
    @Description("Syncs access of the linked Discord channel")
    @Syntax("<group>")
    public void execute(Player player, String groupName) {
        Group group = GroupManager.getGroup(groupName);
        if (group == null) {
            player.sendMessage(ChatColor.RED + "That group does not exist");
            return;
        }
        if (!NameLayerAPI.getGroupManager().hasAccess(group, player.getUniqueId(),
            PermissionType.getPermission("KIRA_MANAGE_CHANNEL"))) {
            player.sendMessage(ChatColor.RED + "You do not have permission to do that");
            return;
        }
        GroupManager gm = NameLayerAPI.getGroupManager();
        PermissionType perm = PermissionType.getPermission("READ_CHAT");
        Collection<UUID> members = new HashSet<>();
        group.getAllMembers().stream().filter(m -> gm.hasAccess(group, player.getUniqueId(), perm))
            .forEach(m -> members.add(m));
        KiraBukkitGatewayPlugin.getInstance().getRabbit().syncGroupChatAccess(group.getName(), members,
            player.getUniqueId());
        player.sendMessage(ChatColor.GREEN + "Attempting to sync members...");
    }
}
