package net.civmc.zorweth.flight;

import com.devotedmc.ExilePearl.ExilePearlPlugin;
import com.google.common.io.ByteArrayDataOutput;
import com.google.common.io.ByteStreams;
import com.sk89q.worldedit.extent.clipboard.Clipboard;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.regions.Region;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.logging.Level;
import net.civmc.zorweth.RocketTransferKeys;
import net.civmc.zorweth.ZorwethPlugin;
import net.civmc.zorweth.mechanics.Fuel;
import net.civmc.zorweth.transfer.RocketBlockPosition;
import net.civmc.zorweth.transfer.RocketChestTransfer;
import net.civmc.zorweth.transfer.RocketEntityPosition;
import net.civmc.zorweth.transfer.RocketManifest;
import net.civmc.zorweth.transfer.RocketManifestChest;
import net.civmc.zorweth.transfer.RocketManifestFileWriter;
import net.civmc.zorweth.transfer.RocketManifestPassenger;
import net.civmc.zorweth.transfer.RocketManifestSerializer;
import net.civmc.zorweth.transfer.RocketPassengerTransfer;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.entity.Player;
import org.bukkit.inventory.CraftingInventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.BundleMeta;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.java.JavaPlugin;
import vg.civcraft.mc.citadel.ReinforcementLogic;
import vg.civcraft.mc.citadel.model.Reinforcement;

// Handles launching logic
public class LaunchHandler {

    public static final double FUEL_ITEM_MASS_KG = 4.0;
    public static final double EXHAUST_VELOCITY_METERS_PER_SECOND = 5_000.0;
    public static final double ROCKET_DRY_MASS_KG = 150.0;
    public static final double SITTING_PLAYER_MASS_KG = 10.0;
    private static final String COMPACTED_LORE = "Compacted Item";

    public static FuelStatus calculateFuelStatus(final Block computer, final List<RocketManifestPassenger> passengers,
                                                  final List<RocketManifestChest> chests) {
        final double cargoMass = calculateCargoMass(chests, passengers);
        final int sittingPlayers = Math.max(1, passengers.size());
        final double nonFuelMass = ROCKET_DRY_MASS_KG + cargoMass + sittingPlayers * SITTING_PLAYER_MASS_KG;
        final double requiredFuelKg = nonFuelMass * (Math.exp(getDeltaVMetersPerSecond() / EXHAUST_VELOCITY_METERS_PER_SECOND) - 1.0);
        final double fuelKg = FlightComputer.getFuelKg(computer);
        return new FuelStatus(
            (int) (fuelKg / FUEL_ITEM_MASS_KG),
            fuelKg,
            requiredFuelKg,
            (int) Math.ceil(requiredFuelKg / FUEL_ITEM_MASS_KG),
            cargoMass,
            sittingPlayers
        );
    }

    public static RocketWeightPayload collectRocketWeightPayload(final Block computer, final Clipboard rocket) {
        final Region region = rocket.getRegion();
        final BlockVector3 schematicNorthWestCorner = region.getMinimumPoint();
        final Block origin = FlightComputer.getRocketOrigin(computer);
        final List<RocketManifestChest> chests = new ArrayList<>();

        for (final BlockVector3 position : region) {
            final BlockVector3 relative = position.subtract(schematicNorthWestCorner);
            final Block actualBlock = origin.getRelative(relative.getX(), relative.getY(), relative.getZ());
            if (actualBlock.getState(false) instanceof Chest chest) {
                chests.add(new RocketManifestChest(
                    new RocketBlockPosition(relative.getX(), relative.getY(), relative.getZ()),
                    chest.getBlockInventory().getStorageContents()
                ));
            }
        }

        final List<RocketManifestPassenger> passengers = new ArrayList<>();
        for (final Player seated : Bukkit.getOnlinePlayers()) {
            if (!seated.getWorld().equals(origin.getWorld())) {
                continue;
            }
            if (seated.getGameMode() == GameMode.SPECTATOR) {
                continue;
            }
            final Location location = seated.getLocation();
            final BlockVector3 relative = BlockVector3.at(
                location.getBlockX() - origin.getX(),
                location.getBlockY() - origin.getY(),
                location.getBlockZ() - origin.getZ()
            );
            if (!region.contains(schematicNorthWestCorner.add(relative)) || !FlightComputer.isSittingWithGSit(seated)) {
                continue;
            }
            passengers.add(new RocketManifestPassenger(
                seated.getUniqueId(),
                new RocketEntityPosition(
                    location.getX() - origin.getX(),
                    location.getY() - origin.getY(),
                    location.getZ() - origin.getZ(),
                    location.getYaw(),
                    location.getPitch()
                ),
                seated.getInventory().getContents(),
                seated.getHealth(),
                seated.getLevel(),
                seated.getExp(),
                seated.getFoodLevel(),
                seated.getSaturation(),
                seated.getExhaustion(),
                seated.getInventory().getHeldItemSlot(),
                seated.getGameMode()
            ));
        }

        return new RocketWeightPayload(passengers, chests, getRemainingFuel(chests, passengers, computer));
    }

    private static double calculateCargoMass(final List<RocketManifestChest> chests,
                                             final List<RocketManifestPassenger> passengers) {
        double mass = 0.0;
        for (final RocketManifestChest chest : chests) {
            mass += calculateItemMass(chest.contents());
        }
        for (final RocketManifestPassenger passenger : passengers) {
            mass += calculateItemMass(passenger.inventoryContents());
        }
        return mass;
    }

    private static double calculateItemMass(final ItemStack[] items) {
        double mass = 0.0;
        for (final ItemStack item : items) {
            if (item == null || item.getType().isAir()) {
                continue;
            }
            int itemAmount = item.getAmount();
            if (isCompacted(item)) {
                itemAmount *= getCompactStackSize(item.getType());
            }
            double itemMass = itemAmount / (double) item.getMaxStackSize();
            if (FlightComputer.isFuel(item)) {
                itemMass = itemAmount * FUEL_ITEM_MASS_KG;
            } else if (Fuel.isCrudeOil(item)) {
                itemMass = itemAmount * Fuel.CRUDE_OIL_ITEM_MASS_KG;
            }
            mass += itemMass;
            if (item.getItemMeta() instanceof BundleMeta bundleMeta) {
                mass += itemAmount * calculateItemMass(bundleMeta.getItems().toArray(ItemStack[]::new));
            }
        }
        return mass;
    }

    private static int getCompactStackSize(final Material material) {
        return switch (material.getMaxStackSize()) {
            case 64 -> 64;
            case 16 -> 16;
            case 1 -> 8;
            default -> 1;
        };
    }

    private static boolean isCompacted(final ItemStack item) {
        if (!item.hasItemMeta()) {
            return false;
        }
        final ItemMeta meta = item.getItemMeta();
        if (!meta.hasLore()) {
            return false;
        }
        for (final String lore : meta.getLore()) {
            if (COMPACTED_LORE.equals(lore)) {
                return true;
            }
        }
        return false;
    }

    public static RocketManifestResult collectLaunchManifest(final ZorwethPlugin plugin, final Block computer, final Player player, Clipboard rocket) {
        final Region region = rocket.getRegion();
        final BlockVector3 schematicNorthWestCorner = region.getMinimumPoint();
        final Block origin = FlightComputer.getRocketOrigin(computer);
        final RocketWeightPayload payload = collectRocketWeightPayload(computer, rocket);
        final Map<Long, Integer> highestRocketYByColumn = new HashMap<>();

        for (final BlockVector3 position : region) {
            final BlockVector3 relative = position.subtract(schematicNorthWestCorner);
            final com.sk89q.worldedit.world.block.BlockState expectedState = rocket.getBlock(position);
            final Material expected = Bukkit.createBlockData(expectedState.getAsString()).getMaterial();
            final Block actualBlock = origin.getRelative(relative.getX(), relative.getY(), relative.getZ());
            final Material actual = actualBlock.getType();
            if (actual != expected) {
                return new RocketManifestResult(null,
                    Component.text("Rocket is not structurally intact", NamedTextColor.RED));
            }
            if (!expected.isAir()) {
                final long column = packColumn(relative.getX(), relative.getZ());
                highestRocketYByColumn.merge(column, actualBlock.getY(), Math::max);
            }
        }

        for (final Map.Entry<Long, Integer> entry : highestRocketYByColumn.entrySet()) {
            final int x = unpackColumnX(entry.getKey()) + origin.getX();
            final int z = unpackColumnZ(entry.getKey()) + origin.getZ();
            for (int y = entry.getValue() + 1; y < origin.getWorld().getMaxHeight(); y++) {
                if (!origin.getWorld().getBlockAt(x, y, z).getType().isAir()) {
                    return new RocketManifestResult(null,
                        Component.text("Rocket launch path is obstructed", NamedTextColor.RED));
                }
            }
        }

        for (final Player seated : Bukkit.getOnlinePlayers()) {
            if (!seated.getWorld().equals(origin.getWorld())) {
                continue;
            }
            if (seated.getGameMode() == GameMode.SPECTATOR) {
                continue;
            }
            final Location location = seated.getLocation();
            final BlockVector3 relative = BlockVector3.at(
                location.getBlockX() - origin.getX(),
                location.getBlockY() - origin.getY(),
                location.getBlockZ() - origin.getZ()
            );
            final boolean insideRocket = region.contains(schematicNorthWestCorner.add(relative));
            if (insideRocket && !FlightComputer.isSittingWithGSit(seated)) {
                return new RocketManifestResult(null,
                    Component.text((seated.equals(player) ? "Pilot" : "Passenger") + " " + seated.getName()
                        + " is not seated.", NamedTextColor.RED));
            }
        }

        final FlightComputerGui.Coordinates destination = FlightComputer.getDestination(computer);
        if (destination == null) {
            return new RocketManifestResult(null,
                Component.text("Destination not set.", NamedTextColor.RED));
        }

        if (containsIllegalItem(payload)) {
            return new RocketManifestResult(null,
                Component.text("Filled maps and pearls cannot be transferred on rockets.", NamedTextColor.RED));
        }

        return new RocketManifestResult(new RocketManifest(
            UUID.randomUUID(),
            plugin.getServerName(),
            plugin.getDestinationServer(),
            origin.getWorld().getName(),
            plugin.getDestinationWorld(),
            new RocketBlockPosition(origin.getX(), origin.getY(), origin.getZ()),
            destination.x(),
            destination.z(),
            player.getUniqueId(),
            getDiamondFlightComputerGroupId(computer),
            payload.passengers(),
            payload.chests(),
            getRemainingFuel(payload.chests(), payload.passengers(), computer),
            FlightComputer.getUsesRemaining(computer)
        ), null);
    }

    private static long packColumn(final int x, final int z) {
        return ((long) x << 32) ^ (z & 0xffffffffL);
    }

    private static int unpackColumnX(final long column) {
        return (int) (column >> 32);
    }

    private static int unpackColumnZ(final long column) {
        return (int) column;
    }

    private static boolean containsIllegalItem(final RocketWeightPayload payload) {
        for (final RocketManifestPassenger passenger : payload.passengers()) {
            if (containsIllegalItem(passenger.inventoryContents())) {
                return true;
            }
        }
        for (final RocketManifestChest chest : payload.chests()) {
            if (containsIllegalItem(chest.contents())) {
                return true;
            }
        }
        return false;
    }

    private static boolean containsIllegalItem(final ItemStack[] contents) {
        for (final ItemStack item : contents) {
            if (item != null && (item.getType() == Material.FILLED_MAP
                || (item.getType() == Material.ENDER_PEARL
                    && Bukkit.getPluginManager().isPluginEnabled("ExilePearl")
                    && ExilePearlPlugin.getApi() != null
                    && ExilePearlPlugin.getApi().getPearlFromItemStack(item) != null))) {
                return true;
            }
            if (item != null && item.getItemMeta() instanceof BundleMeta bundleMeta
                && containsIllegalItem(bundleMeta.getItems().toArray(ItemStack[]::new))) {
                return true;
            }
        }
        return false;
    }

    private static double getRemainingFuel(final List<RocketManifestChest> chests,
                                           final List<RocketManifestPassenger> passengers,
                                           final Block computer) {
        final double cargoMass = calculateCargoMass(chests, passengers);
        final double dryMass = ROCKET_DRY_MASS_KG + cargoMass + passengers.size() * SITTING_PLAYER_MASS_KG;
        final double wetMass = FlightComputer.getFuelKg(computer) + dryMass;
        return wetMass / (Math.exp(getDeltaVMetersPerSecond() / EXHAUST_VELOCITY_METERS_PER_SECOND)) - dryMass;
    }

    private static double getDeltaVMetersPerSecond() {
        return JavaPlugin.getPlugin(ZorwethPlugin.class).getDeltaVMetersPerSecond();
    }

    private static Integer getDiamondFlightComputerGroupId(final Block computer) {
        final Reinforcement reinforcement = ReinforcementLogic.getReinforcementAt(computer.getLocation());
        if (reinforcement == null || reinforcement.getType().getItem() == null
            || reinforcement.getType().getItem().getType() != Material.DIAMOND) {
            return null;
        }
        return reinforcement.getGroupId();
    }

    public static void commitLaunch(final ZorwethPlugin plugin, final Block computer, final Player clicker) {
        if (!computer.getWorld().getName().equals(plugin.getSourceWorld())) {
            clicker.sendMessage(Component.text("Rockets can only launch from the overworld.", NamedTextColor.RED));
            return;
        }

        final LaunchHandler.RocketManifestResult manifestResult = LaunchHandler.collectLaunchManifest(plugin, computer, clicker, plugin.getRocketClipboard());
        if (manifestResult.failure() != null) {
            clicker.sendMessage(manifestResult.failure());
            return;
        }

        final RocketManifest manifest = manifestResult.manifest();
        final LaunchHandler.FuelStatus fuelStatus = LaunchHandler.calculateFuelStatus(computer, manifest.passengers(), manifest.chests());
        if (fuelStatus.currentFuelKg() < fuelStatus.requiredFuelKg()) {
            clicker.sendMessage(Component.text("Rocket is insufficiently fuelled", NamedTextColor.RED));
            return;
        }

        int uses = FlightComputer.getUsesRemaining(computer);
        if (uses <= 0) {
            clicker.sendMessage(Component.text("The rocket is broken beyond repair.", NamedTextColor.RED));
            return;
        }

        final RocketBlockPosition destinationOrigin = findDestinationOrigin(manifest);
        if (destinationOrigin == null) {
            clicker.sendMessage(Component.text("Destination world is not available for landing calculation.", NamedTextColor.RED));
            return;
        }

        final List<RocketPassengerTransfer> passengers;
        final List<RocketChestTransfer> chests;
        try {
            passengers = RocketManifestSerializer.serializePassengers(manifest);
            chests = RocketManifestSerializer.serializeChests(manifest);
        } catch (final RuntimeException exception) {
            plugin.getLogger().log(Level.SEVERE, "Failed to serialize rocket transfer payload", exception);
            clicker.sendMessage(Component.text("Failed to prepare rocket transfer payload.", NamedTextColor.RED));
            return;
        }

        final RocketManifest launchedManifest = new RocketManifest(
            manifest.transferId(),
            manifest.sourceServer(),
            manifest.destinationServer(),
            manifest.sourceWorld(),
            manifest.destinationWorld(),
            manifest.sourceOrigin(),
            manifest.destinationRequestedX(),
            manifest.destinationRequestedZ(),
            manifest.pilotUuid(),
            manifest.flightComputerGroupId(),
            manifest.passengers(),
            manifest.chests(),
            manifest.fuelKg(),
            uses - 1
        );
        clearPassengerState(manifest);
        setSourceClearedMarkers(launchedManifest);
        clearRocket(plugin.getRocketClipboard(), computer);

        for (RocketPassengerTransfer passenger : passengers) {
            plugin.getStasisHandler().putInStasis(Bukkit.getPlayer(passenger.playerUuid()));
        }

        clicker.sendMessage(Component.text("Preparing rocket transfer.", NamedTextColor.GREEN));
        Bukkit.getScheduler().runTaskAsynchronously(plugin, () -> {
            for (int i = 0; i < 5; i++) {
                if (i > 0) {
                    try {
                        Thread.sleep((1 << (i - 1)) * 1000L);
                        plugin.getLogger().log(Level.WARNING, "Retrying transfer #" + i + "...");
                    } catch (final InterruptedException exception) {
                        Thread.currentThread().interrupt();
                        return;
                    }
                }
                try {
                    plugin.getRocketTransferDao().insertPreparedTransfer(launchedManifest, passengers, chests);
                    break;
                } catch (final Exception exception) {
                    plugin.getLogger().log(Level.SEVERE, "Failed to insert prepared rocket transfer", exception);
                }
                if (i == 4) {
                    clicker.sendMessage(Component.text("Rocket launch failed, please contact admins.", NamedTextColor.RED));

                    Bukkit.getScheduler().runTask(plugin, () -> {
                        for (RocketPassengerTransfer passenger : passengers) {
                            Player player = Bukkit.getPlayer(passenger.playerUuid());
                            if (player != null) {
                                plugin.getStasisHandler().removeStasis(player);
                                clearSourceMarkers(player);
                            } else {
                                plugin.getLogger().log(Level.SEVERE, "Unable to clear launch markers from " + passenger.playerUuid());
                            }
                        }
                    });

                    try {
                        plugin.getLogger().log(Level.SEVERE, "Failed to retry launch, writing file..");
                        File write = RocketManifestFileWriter.write(plugin, launchedManifest);
                        plugin.getLogger().log(Level.SEVERE, "Written launch failure to " + write.getName());
                    } catch (final IOException exception) {
                        throw new RuntimeException(exception);
                    }
                    return;
                }
            }

            Bukkit.getScheduler().runTask(plugin, () -> {
                LaunchHandler.connectOrKickPassengers(plugin, launchedManifest);
                clicker.sendMessage(Component.text("Ignition.", NamedTextColor.GREEN));
            });
        });
    }

    private static RocketBlockPosition findDestinationOrigin(final RocketManifest manifest) {
        final World destinationWorld = Bukkit.getWorld(manifest.destinationWorld());
        if (destinationWorld == null) {
            return null;
        }
        final int y = destinationWorld.getHighestBlockYAt(manifest.destinationRequestedX(), manifest.destinationRequestedZ());
        return new RocketBlockPosition(manifest.destinationRequestedX(), y, manifest.destinationRequestedZ());
    }

    private static void clearRocket(Clipboard clipboard, Block computer) {
        final Region region = clipboard.getRegion();
        final BlockVector3 schematicNorthWestCorner = region.getMinimumPoint();
        final Block origin = FlightComputer.getRocketOrigin(computer);

        for (final BlockVector3 position : region) {
            final BlockVector3 relative = position.subtract(schematicNorthWestCorner);
            final Block actualBlock = origin.getRelative(relative.getX(), relative.getY(), relative.getZ());
            Reinforcement reinforcement = ReinforcementLogic.getReinforcementAt(actualBlock.getLocation());
            if (reinforcement != null) {
                reinforcement.setHealth(-1);
            }
            actualBlock.setType(Material.AIR, false);
        }
    }

    private static void clearPassengerState(final RocketManifest manifest) {
        for (final RocketManifestPassenger passenger : manifest.passengers()) {
            final Player player = Bukkit.getPlayer(passenger.playerUuid());
            if (player == null) {
                continue;
            }
            player.getInventory().clear();
            if (player.getOpenInventory().getTopInventory() instanceof CraftingInventory inventory) {
                inventory.clear();
            }
            player.setLevel(0);
            player.setExp(0.0f);
            player.setFoodLevel(20);
            player.setSaturation(5.0f);
            player.setExhaustion(0.0f);
            player.getInventory().setHeldItemSlot(0);
        }
    }

    private static void setSourceClearedMarkers(final RocketManifest manifest) {
        for (final RocketManifestPassenger passenger : manifest.passengers()) {
            final Player player = Bukkit.getPlayer(passenger.playerUuid());
            if (player == null) {
                throw new IllegalStateException("unknown player" + passenger.playerUuid());
            }
            player.getPersistentDataContainer().set(RocketTransferKeys.SOURCE_TRANSFER_ID, PersistentDataType.STRING,
                manifest.transferId().toString());
            player.getPersistentDataContainer().set(RocketTransferKeys.PIONEER, PersistentDataType.BOOLEAN, true);
        }
    }

    private static void clearSourceMarkers(Player player) {
        player.getPersistentDataContainer().remove(RocketTransferKeys.SOURCE_TRANSFER_ID);
    }

    public static void connectOrKickPassengers(final ZorwethPlugin plugin, final RocketManifest manifest) {
        for (final RocketManifestPassenger passenger : manifest.passengers()) {
            final Player player = Bukkit.getPlayer(passenger.playerUuid());
            if (player == null) {
                continue;
            }
            connect(plugin, player, manifest.destinationServer());
            Bukkit.getScheduler().runTaskLater(plugin, () -> {
                final Player laterPlayer = Bukkit.getPlayer(passenger.playerUuid());
                if (laterPlayer != null
                    && manifest.transferId().toString().equals(laterPlayer.getPersistentDataContainer()
                    .get(RocketTransferKeys.SOURCE_TRANSFER_ID, PersistentDataType.STRING))) {
                    laterPlayer.kick(Component.text(plugin.getTransferFailureMessage(), NamedTextColor.RED));
                }
            }, 150L);
        }
    }

    private static void connect(final JavaPlugin plugin, final Player player, final String server) {
        final ByteArrayDataOutput output = ByteStreams.newDataOutput();
        output.writeUTF("Connect");
        output.writeUTF(server);
        player.sendPluginMessage(plugin, "BungeeCord", output.toByteArray());
    }


    public record FuelStatus(int fuelItems, double currentFuelKg, double requiredFuelKg, int requiredFuelItems,
                             double cargoMassKg, int sittingPlayers) {

    }

    public record RocketWeightPayload(List<RocketManifestPassenger> passengers, List<RocketManifestChest> chests,
                                      double fuelKg) {

    }

    public record RocketManifestResult(RocketManifest manifest, Component failure) {

    }
}
