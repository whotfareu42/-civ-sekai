package vg.civcraft.mc.namelayer.command.commands;

import co.aikar.commands.annotation.CommandAlias;
import co.aikar.commands.annotation.Description;
import java.util.UUID;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import vg.civcraft.mc.namelayer.NameLayerAPI;
import vg.civcraft.mc.namelayer.NameLayerPlugin;
import vg.civcraft.mc.namelayer.command.BaseCommandMiddle;
import vg.civcraft.mc.namelayer.group.AutoAcceptHandler;

public class ToggleAutoAcceptInvites extends BaseCommandMiddle {

    private AutoAcceptHandler handler = NameLayerPlugin.getAutoAcceptHandler();

    @CommandAlias("nltaai|autoaccept")
    @Description("Toggle the acceptance of invites.")
    public void execute(CommandSender sender) {
        if (!(sender instanceof Player p)) {
            sender.sendMessage("how would this even work");
            return;
        }
        UUID uuid = NameLayerAPI.getUUID(p.getName());
        final boolean enable = !handler.getAutoAccept(uuid);
        handler.setAutoAcceptAsync(uuid, enable, result -> {
            if (!result.success()) {
                p.sendMessage(ChatColor.RED + result.message());
                return;
            }
            if (enable) {
                p.sendMessage(ChatColor.GREEN + "You will automatically accept group requests.");
            } else {
                p.sendMessage(ChatColor.GREEN + "You will no longer automatically accept group requests.");
            }
        });
    }
}
