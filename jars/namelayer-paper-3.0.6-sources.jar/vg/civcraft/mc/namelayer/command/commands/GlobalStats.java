package vg.civcraft.mc.namelayer.command.commands;

import co.aikar.commands.annotation.CommandAlias;
import co.aikar.commands.annotation.CommandPermission;
import co.aikar.commands.annotation.Description;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.command.CommandSender;
import vg.civcraft.mc.namelayer.NameLayerPlugin;
import vg.civcraft.mc.namelayer.command.BaseCommandMiddle;

public class GlobalStats extends BaseCommandMiddle {

    @CommandAlias("nlgls")
    @CommandPermission("namelayer.admin")
    @Description("Get the amount of global groups.")
    public void execute(final CommandSender sender) {
        Bukkit.getScheduler().runTaskAsynchronously(NameLayerPlugin.getInstance(), () -> {
            int count = NameLayerPlugin.getGroupCache().countGroups();

            sender.sendMessage(ChatColor.GREEN + "The amount of groups are: " + count);
        });
        sender.sendMessage(ChatColor.GREEN + "Stats are being retrieved, please wait.");
    }
}
