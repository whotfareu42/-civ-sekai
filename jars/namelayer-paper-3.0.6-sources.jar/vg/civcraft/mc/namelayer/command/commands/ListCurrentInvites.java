package vg.civcraft.mc.namelayer.command.commands;

import co.aikar.commands.annotation.CommandAlias;
import co.aikar.commands.annotation.Description;
import org.bukkit.entity.Player;
import vg.civcraft.mc.namelayer.NameLayerAPI;
import vg.civcraft.mc.namelayer.command.BaseCommandMiddle;
import vg.civcraft.mc.namelayer.listeners.PlayerListener;

public class ListCurrentInvites extends BaseCommandMiddle {

    @CommandAlias("nllci|listinvites|invites")
    @Description("List your current invites.")
    public void execute(Player sender) {
        sender.sendMessage(PlayerListener.getNotificationsInStringForm(NameLayerAPI.getUUID(sender.getName())));
    }
}
