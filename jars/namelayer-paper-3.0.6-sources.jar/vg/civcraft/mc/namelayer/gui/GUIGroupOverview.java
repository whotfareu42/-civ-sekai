package vg.civcraft.mc.namelayer.gui;

import io.papermc.paper.registry.data.dialog.input.DialogInput;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.UUID;
import java.util.logging.Level;
import net.kyori.adventure.key.Key;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import vg.civcraft.mc.civmodcore.dialog.DialogHelpers;
import vg.civcraft.mc.civmodcore.dialog.DialogManager;
import vg.civcraft.mc.civmodcore.inventory.gui.Clickable;
import vg.civcraft.mc.civmodcore.inventory.gui.ClickableInventory;
import vg.civcraft.mc.civmodcore.inventory.gui.DecorationStack;
import vg.civcraft.mc.civmodcore.inventory.items.ItemUtils;
import vg.civcraft.mc.namelayer.GroupManager;
import vg.civcraft.mc.namelayer.GroupManager.PlayerType;
import vg.civcraft.mc.namelayer.NameLayerAPI;
import vg.civcraft.mc.namelayer.NameLayerPlugin;
import vg.civcraft.mc.namelayer.group.Group;
import vg.civcraft.mc.namelayer.permission.GroupPermission;
import vg.civcraft.mc.namelayer.permission.PermissionType;

public class GUIGroupOverview {

    private int currentPage;
    private Player p;
    private static GroupManager gm;
    private boolean autoAccept;

    public GUIGroupOverview(Player p) {
        if (gm == null) {
            gm = NameLayerAPI.getGroupManager();
        }
        autoAccept = NameLayerPlugin.getAutoAcceptHandler().getAutoAccept(p.getUniqueId());
        this.p = p;
        this.currentPage = 0;
    }

    public void showScreen() {

        ClickableInventory ci = new ClickableInventory(54, p.getName() + "'s groups");
        final List<Clickable> groups = getGroupClickables();
        if (groups.size() < 45 * currentPage) {
            // would show an empty page, so go to previous
            currentPage--;
            showScreen();
        }

        for (int i = 45 * currentPage; i < 45 * (currentPage + 1)
            && i < groups.size(); i++) {
            ci.setSlot(groups.get(i), i - (45 * currentPage));
        }

        // create group
        ci.setSlot(getCreateGroupClickable(), 46);
        //join group
        ci.setSlot(getJoinGroupClickable(), 47);

        //autoaccept toggle
        ItemStack toggle = MenuUtils.toggleButton(autoAccept, ChatColor.GOLD + "Automatically accept group invites", true);
        Clickable toggleClick = new Clickable(toggle) {

            @Override
            public void clicked(Player p) {
                final boolean enable = !autoAccept;
                NameLayerPlugin.getAutoAcceptHandler().setAutoAcceptAsync(p.getUniqueId(), enable, result -> {
                    if (result.success()) {
                        autoAccept = enable;
                        if (enable) {
                            p.sendMessage(ChatColor.GREEN + "You will automatically accept group invites");
                            NameLayerPlugin.log(Level.INFO,
                                p.getName() + " turned autoaccept for invites on "
                                    + " via the gui");
                        } else {
                            p.sendMessage(ChatColor.GREEN + "You will no longer automatically accept group invites");
                            NameLayerPlugin.log(Level.INFO,
                                p.getName() + " turned autoaccept for invites off "
                                    + " via the gui");
                        }
                    } else {
                        p.sendMessage(ChatColor.RED + result.message());
                    }
                    showScreen();
                });
            }
        };
        ci.setSlot(toggleClick, 48);

        // previous button
        if (currentPage > 0) {
            ItemStack back = new ItemStack(Material.ARROW);
            ItemUtils.setDisplayName(back, ChatColor.GOLD + "Go to previous page");
            Clickable baCl = new Clickable(back) {

                @Override
                public void clicked(Player arg0) {
                    if (currentPage > 0) {
                        currentPage--;
                    }
                    showScreen();
                }
            };
            ci.setSlot(baCl, 45);
        }
        // next button
        if ((45 * (currentPage + 1)) < groups.size()) {
            ItemStack forward = new ItemStack(Material.ARROW);
            ItemUtils.setDisplayName(forward, ChatColor.GOLD + "Go to next page");
            Clickable forCl = new Clickable(forward) {

                @Override
                public void clicked(Player arg0) {
                    if ((45 * (currentPage + 1)) < groups.size()) {
                        currentPage++;
                    }
                    showScreen();
                }
            };
            ci.setSlot(forCl, 53);
        }

        // close button
        ItemStack backToOverview = AbstractGroupGUI.goBackStack();
        ItemUtils.setDisplayName(backToOverview, ChatColor.GOLD + "Close");
        ci.setSlot(new Clickable(backToOverview) {

            @Override
            public void clicked(Player arg0) {
                ClickableInventory.forceCloseInventory(arg0);
            }
        }, 49);
        ci.showInventory(p);
    }

    private List<Clickable> getGroupClickables() {
        String defaultGroupName = gm.getDefaultGroup(p.getUniqueId());
        List<String> groupNames = gm.getAllGroupNames(p.getUniqueId());
        groupNames.sort(Comparator.comparing((String g) -> {
                Group group = GroupManager.getGroup(g);
                return group != null && group.isOwner(p.getUniqueId());
            }).thenComparing((String g) -> {
                Group group = GroupManager.getGroup(g);
                if (group != null) {
                    return group.getPlayerType(p.getUniqueId());
                } else {
                    return PlayerType.NOT_BLACKLISTED;
                }
            }).reversed()
            .thenComparing(String.CASE_INSENSITIVE_ORDER));
        List<Clickable> result = new ArrayList<Clickable>();
        Set<String> alreadyProcessed = new HashSet<String>();
        for (String groupName : groupNames) {
            if (alreadyProcessed.contains(groupName)) {
                continue;
            }
            final Group g = GroupManager.getGroup(groupName);
            if (g == null) {
                continue;
            }
            Clickable c;
            PlayerType pType = g.getPlayerType(p.getUniqueId());
            if (pType == null) {
                continue;
            }
            ItemStack is = null;
            switch (pType) {
                case MEMBERS:
                    is = new ItemStack(Material.LEATHER_CHESTPLATE);
                    ItemUtils.addLore(is, ChatColor.AQUA + "Your rank: Member");
                    break;
                case MODS:
                    is = AbstractGroupGUI.modStack();
                    ItemUtils.addLore(is, ChatColor.AQUA + "Your rank: Mod");
                    break;
                case ADMINS:
                    is = new ItemStack(Material.IRON_CHESTPLATE);
                    ItemUtils.addLore(is, ChatColor.AQUA + "Your rank: Admin");
                    break;
                case OWNER:
                    is = new ItemStack(Material.DIAMOND_CHESTPLATE);
                    if (g.isOwner(p.getUniqueId())) {
                        ItemUtils.addLore(is, ChatColor.AQUA
                            + "Your rank: Primary owner");
                    } else {
                        ItemUtils.addLore(is, ChatColor.AQUA + "Your rank: Owner");
                    }
                    break;
            }
            if (is == null) {
                continue;
            }
            ItemMeta im = is.getItemMeta();
            im.addItemFlags(ItemFlag.HIDE_ATTRIBUTES, ItemFlag.HIDE_ENCHANTS);
            if (g.getName().equals(defaultGroupName)) {
                List<String> lore = im.getLore();
                lore.add(ChatColor.DARK_AQUA + "Your current default group");
                im.setLore(lore);
                im.setEnchantmentGlintOverride(true);
            }
            is.setItemMeta(im);
            if (gm.hasAccess(g, p.getUniqueId(),
                PermissionType.getPermission("GROUPSTATS"))) {
                ItemUtils.addLore(
                    is,
                    ChatColor.AQUA
                        + String.valueOf(g.getAllMembers().size())
                        + " member"
                        + (g.getAllMembers().size() > 1 ? "s" : ""));
            }
            ItemUtils.setDisplayName(is, ChatColor.GOLD + g.getName());
            if (gm.hasAccess(g, p.getUniqueId(),
                PermissionType.getPermission("OPEN_GUI"))) {
                c = new Clickable(is) {

                    @Override
                    public void clicked(Player arg0) {
                        MainGroupGUI mgui = new MainGroupGUI(p, g);
                    }
                };
            } else {
                ItemUtils.addLore(is, ChatColor.RED
                    + "You aren't permitted to open", ChatColor.RED
                    + "the GUI for this group");
                c = new DecorationStack(is);
            }
            result.add(c);
            alreadyProcessed.add(groupName);
        }
        return result;
    }

    private Clickable getCreateGroupClickable() {
        ItemStack is = new ItemStack(Material.APPLE);
        ItemUtils.setDisplayName(is, ChatColor.GOLD + "Create group");
        Clickable c = new Clickable(is) {

            @Override
            public void clicked(final Player p) {
                final String NAME_ID = "group_name", PASSWORD_ID = "group_password";
                DialogManager.showDialog(
                    p,
                    Key.key("namelayer", "create_group"),
                    Component.text("Create Group?"),
                    List.of(),
                    List.of(
                        DialogInput.text(NAME_ID, Component.text("Group name:", NamedTextColor.GOLD))
                            .maxLength(32)
                            .build(),
                        DialogInput.text(PASSWORD_ID, Component.text("Password (optional):", NamedTextColor.GOLD))
                            .maxLength(256)
                            .build()
                    ),
                    (view) -> {
                        String groupName = DialogHelpers.getAssuredText(view, NAME_ID);
                        if (groupName.equals("")) {
                            p.sendMessage(ChatColor.RED
                                + "You didn't enter anything!");
                            showScreen();
                            return;
                        }
                        // enforce regulations on the name
                        if (groupName.length() > 32) {
                            p.sendMessage(ChatColor.RED
                                + "The group name is not allowed to contain more than 32 characters");
                            showScreen();
                            return;
                        }
                        Charset latin1 = StandardCharsets.ISO_8859_1;
                        boolean invalidChars = false;
                        if (!latin1.newEncoder().canEncode(groupName)) {
                            invalidChars = true;
                        }

                        for (char c : groupName.toCharArray()) {
                            if (Character.isISOControl(c)) {
                                invalidChars = true;
                            }
                        }

                        if (invalidChars) {
                            p.sendMessage(ChatColor.RED
                                + "You used characters, which are not allowed");
                            showScreen();
                            return;
                        }

                        if (GroupManager.getGroup(groupName) != null) {
                            p.sendMessage(ChatColor.RED
                                + "That group is already taken. Try another unique group name.");
                            showScreen();
                            return;
                        }

                        final UUID uuid = p.getUniqueId();
                        final boolean adminOverride = p.isOp() || p.hasPermission("namelayer.admin");
                        final int groupLimit = NameLayerPlugin.getInstance().getGroupLimit();
                        Group g = new Group(groupName, uuid, false, null, -1, System.currentTimeMillis(), "GRAY");
                        gm.createGroupAsync(g, groupLimit, adminOverride);
                    }
                );
            }
        };
        return c;
    }

    private Clickable getJoinGroupClickable() {
        ItemStack is = new ItemStack(Material.CHEST);
        ItemUtils.setDisplayName(is, ChatColor.GOLD + "Join password protected group");
        Clickable c = new Clickable(is) {

            @Override
            public void clicked(final Player p) {
                final String NAME_ID = "group_name", PASSWORD_ID = "group_password";
                DialogManager.showDialog(
                    p,
                    Key.key("namelayer", "join_group"),
                    Component.text("Join Password-Protected Group?"),
                    List.of(),
                    List.of(
                        DialogInput.text(NAME_ID, Component.text("Group name:", NamedTextColor.GOLD))
                            .maxLength(32)
                            .build(),
                        DialogInput.text(PASSWORD_ID, Component.text("Password:", NamedTextColor.GOLD))
                            .maxLength(256)
                            .build()
                    ),
                    (view) -> {
                        String groupName = DialogHelpers.getAssuredText(view, NAME_ID);
                        final Group g = gm.getGroup(groupName);
                        if (g == null) {
                            p.sendMessage(ChatColor.RED + "This group doesn't exist");
                            showScreen();
                            return;
                        }
                        if (g.isMember(p.getUniqueId())) {
                            p.sendMessage(ChatColor.RED + "You are already a member of this group");
                            showScreen();
                            return;
                        }
                        final String password = view.getText(PASSWORD_ID);
                        if (g.getPassword() == null || !g.getPassword().equals(password)) {
                            p.sendMessage(ChatColor.RED + "Wrong password");
                            showScreen();
                            return;
                        }
                        Group gro = ensureFreshGroup(g);
                        GroupPermission groupPerm = gm.getPermissionforGroup(gro);
                        PlayerType pType = groupPerm.getFirstWithPerm(PermissionType.getPermission("JOIN_PASSWORD"));
                        if (pType == null) {
                            p.sendMessage(ChatColor.RED + "Someone derped. This group does not have the specified permission to let you join, sorry.");
                            showScreen();
                            return;
                        }
                        if (NameLayerPlugin.getBlackList().isBlacklisted(gro, p.getUniqueId())) {
                            p.sendMessage(ChatColor.RED + "You can not join a group you have been blacklisted from");
                            showScreen();
                            return;
                        }
                        NameLayerPlugin.log(Level.INFO,
                            p.getName() + " joined with password "
                                + " to group " + g.getName()
                                + " via the gui");
                        gro.joinGroupAsync(p.getUniqueId(), password, pType, result -> {
                            if (result.success()) {
                                p.sendMessage(ChatColor.GREEN + "You have successfully been added to " + gro.getName());
                            } else {
                                p.sendMessage(ChatColor.RED + result.message());
                            }
                            showScreen();
                        });
                    }
                );
            }
        };
        return c;
    }

    private Group ensureFreshGroup(Group g) {
        if (!g.isValid()) {
            return GroupManager.getGroup(g.getName());
        }
        return g;
    }
}
